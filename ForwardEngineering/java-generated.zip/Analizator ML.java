public class Analizator ML {

  public void validateFileType( idSample) {
  }

  public void validateAudio( idSample) {
  }

  public void generateDiagnosis() {
  }

  public void sendSampleToDoctor() {
  }

  public void sendResultToPatient() {
  }

}