public class Sample {

  public Integer idSample;

  public Integer idUser;

  public Float resultProbability;

  public Date submitDate;

  public Date uploadDate;

}