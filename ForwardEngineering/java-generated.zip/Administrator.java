public class Administrator {

  public Integer field;

  public void addClinic() {
  }

  public void removeAccount() {
  }

  public void assignPatientToDoctor() {
  }

}