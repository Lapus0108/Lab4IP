public class Pacient {

  public Date dataNasterii;

  public String Gen;

  public String istoricMedical;

  public void uploadSample( currentSample) {
  }

  public void editSample( currentSample) {
  }

  public void viewPastDiagnosis( idUser) {
  }

}