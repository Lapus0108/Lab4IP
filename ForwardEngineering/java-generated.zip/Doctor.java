public class Doctor {

  public String specializare;

  public String clinica;

  public void viewPatientsHistory() {
  }

  public void addSampleManually() {
  }

  public void newOperation() {
  }

  public void listenSample() {
  }

  public void analyzeSample() {
  }

  public void validateDiagnosis() {
  }

}