public class Utilizator {

  public Integer idUser;

  public String email;

  public String numeComplet;

  public void login( email,  parola) {
  }

  public void logout( idUser) {
  }

  public void forgotPassword( email) {
  }

  public void validateFields( email,  parola) {
  }

  public void createAccount( email,  numeComplet,  parola) {
  }

  public void updateProfile() {
  }

}