public class Dataset {

  public Sample* samples;

  public void addSample( newSample) {
  }

  public void removeSample( idSample) {
  }

}