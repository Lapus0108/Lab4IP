import java.util.Date;

public class Pacient {
  public Date dataNasterii;
  
  public String Gen;
  
  public String istoricMedical;
  
  public void uploadSample(Sample paramSample) {}
  
  public void editSample(Sample paramSample) {}
  
  public void viewPastDiagnosis(int paramInt) {}
}


/* Location:              /Users/mihnearadu/UAIC/Lab4IP/compiled/!/Pacient.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */