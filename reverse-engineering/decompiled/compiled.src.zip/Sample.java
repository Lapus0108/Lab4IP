import java.util.Date;

public class Sample {
  public Integer idSample;
  
  public Integer idUser;
  
  public Float resultProbability;
  
  public Date submitDate;
  
  public Date uploadDate;
}


/* Location:              /Users/mihnearadu/UAIC/Lab4IP/compiled/!/Sample.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */