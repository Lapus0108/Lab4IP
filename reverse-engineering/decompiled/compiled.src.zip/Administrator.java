public class Administrator {
  public Integer field;
  
  public void addClinic() {}
  
  public void removeAccount() {}
  
  public void assignPatientToDoctor() {}
}


/* Location:              /Users/mihnearadu/UAIC/Lab4IP/compiled/!/Administrator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */