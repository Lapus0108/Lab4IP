public class Utilizator {
  public Integer idUser;
  
  public String email;
  
  public String numeComplet;
  
  public void login(String paramString1, String paramString2) {}
  
  public void logout(int paramInt) {}
  
  public void forgotPassword(String paramString) {}
  
  public void validateFields(String paramString1, String paramString2) {}
  
  public void createAccount(String paramString1, String paramString2, String paramString3) {}
  
  public void updateProfile(Utilizator paramUtilizator) {}
}


/* Location:              /Users/mihnearadu/UAIC/Lab4IP/compiled/!/Utilizator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */