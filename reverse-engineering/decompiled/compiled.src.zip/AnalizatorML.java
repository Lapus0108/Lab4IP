public class AnalizatorML {
  public void validateFileType(int paramInt) {}
  
  public void validateAudio(int paramInt) {}
  
  public void generateDiagnosis() {}
  
  public void sendSampleToDoctor() {}
  
  public void sendResultToPatient() {}
}


/* Location:              /Users/mihnearadu/UAIC/Lab4IP/compiled/!/AnalizatorML.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */